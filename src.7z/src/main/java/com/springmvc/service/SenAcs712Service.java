package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.SenAcs712;

/**
 * 電流acs712感應資料的Service介面
 * 
 * @author hrne
 *
 */
public interface SenAcs712Service extends BaseService<SenAcs712>{


}