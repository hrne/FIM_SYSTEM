package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.ModSen;

/**
 * 感應模組的Service介面
 * 
 * @author hrne
 *
 */
public interface ModSenService extends BaseService<ModSen>{



}