package com.springmvc.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springmvc.entity.SenDht11;
import com.springmvc.service.SenDht11Service;

@Controller
public class ChartController {

	@Autowired
	private SenDht11Service senDht11Service;

	@RequestMapping("/chart/showchart")
	public String showChart(Long locNo, Model model, HttpServletRequest request) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date nowtime = new Date();
		String startDate = request.getParameter("startDate");// 获取输入的日期
		// 判断日期输入是否为空，若为空按当前日期查询
		if (StringUtils.isEmpty(startDate)) {
			startDate = sdf.format(nowtime);
		}
		// 查询数据
		List<SenDht11> senDht11List = senDht11Service.findAll();

		StringBuffer xAxis = new StringBuffer();
		StringBuffer series = new StringBuffer();
		StringBuffer seriestest = new StringBuffer();
		// 格式化数据，格式为[time1,time2,....],[value1,value2,....]
		xAxis.append("[");
		series.append("[{name : 'temp',data : [");
		seriestest.append("[");

		for (SenDht11 senDht11 : senDht11List) {
			xAxis.append("'").append(senDht11.getUpdateDate()).append("',");
			series.append(senDht11.getTempCal()).append(",");
			seriestest.append("{ x : ").append(senDht11.getUpdateDate().getTime()).append(", y : ").append(senDht11.getTempCal()).append("},");
		}

		xAxis.deleteCharAt(xAxis.length()-1);
		series.deleteCharAt(series.length()-1);
		seriestest.deleteCharAt(seriestest.length()-1);
		
		xAxis.append("]");
		series.append("]}]");
		seriestest.append("]");
		
		System.out.println(xAxis);
		System.out.println(series);
		System.out.println(seriestest);

		model.addAttribute("xAxis", xAxis);
		model.addAttribute("series", series);
		model.addAttribute("seriestest", seriestest);

		return "/test/test";
	}
	
	@RequestMapping(value ="/chart/ajax", method = RequestMethod.POST)
	@ResponseBody
	public String getChartAjax() {
		List<SenDht11> senDht11List = senDht11Service.findAll();

		StringBuffer xAxis = new StringBuffer();
		StringBuffer series = new StringBuffer();
		StringBuffer seriestest = new StringBuffer();
		// 格式化数据，格式为[time1,time2,....],[value1,value2,....]
		xAxis.append("[");
		series.append("[{name4 : 'temp',data : [");
		
		seriestest.append("[");

		for (SenDht11 senDht11 : senDht11List) {
			xAxis.append("'").append(senDht11.getUpdateDate()).append("',");
			series.append(senDht11.getTempCal()).append(",");
			seriestest.append("{ x : ").append(senDht11.getTempCal()).append(", y : 50 },");
		}

		xAxis.deleteCharAt(xAxis.length()-1);
		series.deleteCharAt(series.length()-1);
		seriestest.deleteCharAt(seriestest.length()-1);
		
		xAxis.append("]");
		series.append("]}]");
		seriestest.append("]");
		
		System.out.println(xAxis);
		System.out.println(series);
		System.out.println(seriestest);
		
		JSONObject obj = new JSONObject();
		obj.put("xAxis2", xAxis);
		obj.put("series2", series);
		obj.put("seriestest", seriestest);

		
		System.out.println(obj.toString());
		return obj.toString();
	}
}
