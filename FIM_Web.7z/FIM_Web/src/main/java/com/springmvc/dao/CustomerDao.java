package com.springmvc.dao;


import java.util.List;

import com.modle.dao.BaseDao;
import com.springmvc.entity.Customer;

public interface CustomerDao {

    public List < Customer > getCustomers();

    public void saveCustomer(Customer theCustomer);

    public Customer getCustomer(int theId);

    public void deleteCustomer(int theId);
}