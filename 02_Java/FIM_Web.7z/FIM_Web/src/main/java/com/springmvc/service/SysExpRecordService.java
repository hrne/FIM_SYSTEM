package com.springmvc.service;

import java.util.List;

import com.modle.service.BaseService;
import com.springmvc.entity.SenDht11;
import com.springmvc.entity.SysExpRecord;

/**
 * 實驗紀錄資料的Service介面
 * 
 * @author hrne
 *
 */
public interface SysExpRecordService extends BaseService<SysExpRecord>{


}