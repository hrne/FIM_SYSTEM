package com.springmvc.dao;

import com.modle.dao.BaseDao;
import com.springmvc.entity.ModRespLog;

/**
 * 感應紀錄的Dao介面
 * 
 * @author hrne
 *
 */
public interface ModRespLogDao extends BaseDao<ModRespLog>{


}