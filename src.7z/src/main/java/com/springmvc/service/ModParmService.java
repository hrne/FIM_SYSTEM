package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.ModParm;

/**
 * 感應模組參數的Service介面
 * 
 * @author hrne
 *
 */
public interface ModParmService extends BaseService<ModParm>{



}