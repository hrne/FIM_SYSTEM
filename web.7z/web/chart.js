<%@page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@taglib prefix="s" uri="http://www.springframework.org/tags"%>

<script type="text/javascript"
	src="../vendor/datatables/highcharts/highcharts.js"></script>
<script type="text/javascript"
	src="../vendor/datatables/highcharts/highcharts-more.js"></script>
<script type="text/javascript"
	src="../vendor/datatables/highcharts/highcharts-3d.js"></script>

<script>
	$(function() {
		var chart = $('#container2').highcharts(
				{
					chart : {
						type : 'line'
					},
					title : {
						text : 'Monthly Average Temperature'
					},
					subtitle : {
						text : 'Source: WorldClimate.com'
					},
					rangeSelector : {
						buttons : [ {
							count : 1,
							type : 'minute',
							text : '1M'
						}, {
							count : 5,
							type : 'minute',
							text : '5M'
						}, {
							type : 'all',
							text : 'All'
						} ],
						inputEnabled : false,
						selected : 0
					},
					xAxis : {
						categories : [ '2020-04-23 21:21:06.0',
								'2020-04-23 21:21:06.0',
								'2020-04-23 21:21:06.0',
								'2020-04-23 21:21:06.0',
								'2020-04-23 21:49:13.0',
								'2020-04-29 16:19:54.0' ]
					},
					yAxis : {
						title : {
							text : 'Temperature (°C)'
						}
					},
					plotOptions : {
						line : {
							dataLabels : {
								enabled : true
							},
							enableMouseTracking : true
						}
					},
					series : [ {
						name : 'temp',
						data : [ 22.6, 23.6, 19.6, 20.6, 23.6, 70 ]
					} ]
				});
	});
</script>



<script type="text/javascript">
	$(function() {
		setInterval(refresh, 2000); //每3秒刷新一次
		function refresh() {
			$.ajax({
				type : "post",
				dataType : 'json',
				url : 'ajax',
				success : function(data) {

					var se1 = data;

					console.log(data.series2);

					$('#container2').highcharts().xAxis[0].update({
						categories : [ '2020-04-23 21:21:06.0',
								'2020-04-23 21:21:06.0',
								'2020-04-23 21:21:06.0',
								'2020-04-23 21:21:06.0',
								'2020-04-23 21:49:13.0',
								'2020-04-29 16:19:54.0',
								'2020-04-29 20:26:55.0' ]
					});

					$('#container2').highcharts().addSeries(data.series2);

				}
			});
		}
	})
</script>

<div id="page-wrapper">
	<!-- /.row -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<!-- /.panel-heading -->
				<div class="panel-body" id="dht11">
					<div id="container2"></div>
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-12 -->
	</div>
</div>
