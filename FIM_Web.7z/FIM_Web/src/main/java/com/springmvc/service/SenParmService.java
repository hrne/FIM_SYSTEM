package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.SenParm;

/**
 * 感應模組參數的Service介面
 * 
 * @author hrne
 *
 */
public interface SenParmService extends BaseService<SenParm>{



}