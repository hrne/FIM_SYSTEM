package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.SenMod;

/**
 * 感應模組的Service介面
 * 
 * @author hrne
 *
 */
public interface SenModService extends BaseService<SenMod>{



}