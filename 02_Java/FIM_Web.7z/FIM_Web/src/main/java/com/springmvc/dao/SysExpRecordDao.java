package com.springmvc.dao;

import java.util.List;

import com.modle.dao.BaseDao;
import com.springmvc.entity.SenDht11;
import com.springmvc.entity.SysExpRecord;

/**
 * 實驗紀錄資料的Dao介面
 * 
 * @author hrne
 *
 */
public interface SysExpRecordDao extends BaseDao<SysExpRecord>{
			

}