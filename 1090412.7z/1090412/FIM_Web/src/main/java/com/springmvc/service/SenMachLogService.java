package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.SenMachLog;

/**
 * 工具機資料更新紀錄的Service介面
 * 
 * @author hrne
 *
 */
public interface SenMachLogService extends BaseService<SenMachLog>{



}