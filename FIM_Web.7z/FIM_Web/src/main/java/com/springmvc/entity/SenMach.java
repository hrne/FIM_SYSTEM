package com.springmvc.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.JoinColumn;

/**
 * 工具機資料
 * 
 * @author hrne
 *
 */
@Entity
@Table(name = "Z_Sen_Mach")
public class SenMach {

	@Id
	@SequenceGenerator(name = "gen", sequenceName = "SEQ_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gen")
	@Column(name = "id")
	private Integer id;

	/**
	 * 工具機名稱
	 */
	@Column(name = "mach_name")
	private String machName;

	/**
	 * ip位址
	 */
	@Column(name = "ip")
	private String ip;

	/**
	 * 工具機是否啟用
	 */
	@Column(name = "mach_enable", nullable = false)
	private boolean machEnable = true;

	/**
	 * 更新時間，透過SQL自動產生
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_date", insertable = false, updatable = false)
	private Date updateDate;

	/**
	 * 與感應模組的關聯
	 */
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "z_sen_mach_mod_r", joinColumns = @JoinColumn(name = "sen_mach_id"), inverseJoinColumns = @JoinColumn(name = "sen_mod_id"))
	private Set<SenMod> senModSet;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 工具機名稱
	 */
	public String getMachName() {
		return machName;
	}

	public void setMachName(String machName) {
		this.machName = machName;
	}

	/**
	 * ip位址
	 */
	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	/**
	 * 工具機是否啟用
	 */
	public boolean isMachEnable() {
		return machEnable;
	}

	public void setMachEnable(boolean machEnable) {
		this.machEnable = machEnable;
	}

	/**
	 * 更新時間，透過SQL自動產生
	 */
	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * 與感應模組的關聯
	 */
	public Set<SenMod> getSenModSet() {
		return senModSet;
	}

	public void setSenModSet(Set<SenMod> senModSet) {
		this.senModSet = senModSet;
	}

	// 頁面使用

	/**
	 * 依據machEnable顯示:啟用/關閉
	 */
	public String getShonEnableName() {
		if (isMachEnable()) {
			return "啟用";
		} else {
			return "關閉";
		}
	}

	public boolean isNew() {
		return (this.id == null);
	}
	
	public List<String> getShonSenMod() {
		List<String> senModList = new ArrayList<String>();
		for(SenMod bo:getSenModSet()) {
			senModList.add(bo.getMachName());
		}
		return senModList;
	}
	

	// <sf:checkboxes path="framework" />
	@Transient
	private List<Integer> senModsID;

	public List<Integer> getSenModsID() {
		return senModsID;
	}

	public void setSenModsID(List<Integer> senModsID) {
		this.senModsID = senModsID;
	}


}