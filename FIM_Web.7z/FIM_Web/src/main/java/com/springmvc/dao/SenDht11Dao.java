package com.springmvc.dao;

import com.modle.dao.BaseDao;
import com.springmvc.entity.SenDht11;

/**
 * 溫濕度dht11感應資料的Dao介面
 * 
 * @author hrne
 *
 */
public interface SenDht11Dao extends BaseDao<SenDht11>{


}