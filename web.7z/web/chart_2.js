<%@page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@taglib prefix="s" uri="http://www.springframework.org/tags"%>

<script type="text/javascript"
	src="../vendor/datatables/highcharts/highcharts.js"></script>
<script type="text/javascript"
	src="../vendor/datatables/highcharts/highcharts-more.js"></script>
<script type="text/javascript"
	src="../vendor/datatables/highcharts/highcharts-3d.js"></script>

<script>
	$(function() {
		var series1 = ${seriestest};
		console.log(series1);
		var chart = $('#container2').highcharts(
				{
					chart : {
						type : 'line',
						events : {
							load : function() {
								var series = this.series;

								setInterval(function() {
									for (var k = 0; k < series.length; k++) {
										console.log(series[k].options.id);
										series[k].addPoint(
												[ 1588163216000, 70 ], true,
												true);
									}

								}, 1000);
							}
						}
					},
					title : {
						text : 'Monthly Average Temperature'
					},
					subtitle : {
						text : 'Source: WorldClimate.com'
					},
					xAxis : [ {
						type : 'datetime',
						labels : {
							format : '{value:%H:%M}'
						},
						tickPixelInterval: 120
					} ],
					yAxis : {
						title : {
							text : 'Temperature (°C)'
						},
						max : 100,
						min : 0
					},
					plotOptions : {
						line : {
							dataLabels : {
								enabled : true
							},
							enableMouseTracking : true
						}
					},
					series : [ {
						id : 1,
						name : 'temp',
						data : series1

					} ]
				});
	});
</script>


<div id="page-wrapper">
	<!-- /.row -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<!-- /.panel-heading -->
				<div class="panel-body" id="dht11">
					<div id="container2"></div>
				</div>
				<!-- /.panel-body -->
			</div>
			<!-- /.panel -->
		</div>
		<!-- /.col-lg-12 -->
	</div>
</div>
