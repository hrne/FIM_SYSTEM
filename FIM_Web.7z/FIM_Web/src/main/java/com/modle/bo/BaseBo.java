package com.modle.bo;


/**
 * BO Base
 * 
 * @author hrne
 * 
 */
public interface BaseBo {

	
}