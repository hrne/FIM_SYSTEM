package com.springmvc.service;

import com.modle.service.BaseService;
import com.springmvc.entity.ModUpdateLog;

/**
 * 感應裝置更新紀錄Service介面
 * 
 * @author hrne
 *
 */
public interface ModUpdateLogService extends BaseService<ModUpdateLog>{



}