package com.springmvc.dao;

import com.modle.dao.BaseDao;
import com.springmvc.entity.ModUpdateLog;

/**
 * 感應裝置更新紀錄Dao介面
 * 
 * @author hrne
 *
 */
public interface ModUpdateLogDao extends BaseDao<ModUpdateLog>{


}