package com.springmvc.dao;

import com.modle.dao.BaseDao;
import com.springmvc.entity.SenAcs712;

/**
 * 電流acs712感應資料的Dao介面
 * 
 * @author hrne
 *
 */
public interface SenAcs712Dao extends BaseDao<SenAcs712>{
			


}